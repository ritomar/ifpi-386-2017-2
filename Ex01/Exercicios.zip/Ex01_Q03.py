def Maior(a, b):
    if a > b:
        return a
    else:
        return b

print(Maior(5, 4))
